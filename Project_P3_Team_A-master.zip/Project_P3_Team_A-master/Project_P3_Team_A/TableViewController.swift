//
//  TableViewController.swift
//  Project_P3_Team_A
//
//  Created by Morgan Houston on 11/12/19.
//  Copyright © 2019 Team A. All rights reserved.
//

import Foundation
import UIKit

class TableViewController: UITableViewController {
    
    //For long press on table cell
    @IBAction func editTrain(_ gestureRecognizer: UILongPressGestureRecognizer) {
        if gestureRecognizer.state == .began {
            //seque to view controller
        }
         
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        <#code#>
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        <#code#>
    }
    
    
}

